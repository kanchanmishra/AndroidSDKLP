package com.bupa.mishk.mynewapplication;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.liveperson.infra.CampaignInfo;
import com.liveperson.infra.ConversationViewParams;
import com.liveperson.infra.Infra;
import com.liveperson.infra.InitLivePersonProperties;
import com.liveperson.infra.LPAuthenticationParams;
import com.liveperson.infra.callbacks.InitLivePersonCallBack;
import com.liveperson.infra.messaging_ui.fragment.ConversationFragment;
import com.liveperson.messaging.sdk.api.LivePerson;
import com.liveperson.messaging.sdk.api.model.ConsumerProfile;
import com.bupa.mishk.mynewapplication.Utils.AppStorage;


public class ActivityCustom extends AppCompatActivity {

    private static final String TAG = ActivityCustom.class.getSimpleName();
    private static final String LIVEPERSON_FRAGMENT = "liveperson_fragment";
    private ConversationFragment mConversationFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom);

        Log.i(TAG, "onCreate savedInstanceState = " + savedInstanceState );
        LivePerson.initialize(getApplicationContext(), new InitLivePersonProperties(AppStorage.brandID, AppStorage.SDK_SAMPLE_FCM_APP_ID, new InitLivePersonCallBack() {
            @Override
            public void onInitSucceed() {
                Log.i(TAG, "onInitSucceed");

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        initFragment();
                    }
                });
                setCallBack();

                //LivePerson.setUserProfile(appId, firstName, lastName, phone);
                ConsumerProfile consumerProfile = new ConsumerProfile.Builder()
                        .setFirstName("K")
                        .setLastName("M")
                        .setPhoneNumber("")
                        .build();
                LivePerson.setUserProfile(consumerProfile);

                //Constructing the notification builder for the upload/download foreground service and passing it to the SDK.
               /*

                Notification.Builder uploadBuilder = NotificationUI.createUploadNotificationBuilder(getApplicationContext());
                Notification.Builder downloadBuilder = NotificationUI.createDownloadNotificationBuilder(getApplicationContext());
                LivePerson.setImageServiceUploadNotificationBuilder(uploadBuilder);
                LivePerson.setImageServiceDownloadNotificationBuilder(downloadBuilder);
                */
            }

            @Override
            public void onInitFailed(Exception e) {
                Log.e(TAG, "onInitFailed : " + e.getMessage());
            }
        }));
        }

    private void initFragment() {
        mConversationFragment = (ConversationFragment) getSupportFragmentManager().findFragmentByTag(LIVEPERSON_FRAGMENT);
        Log.d(TAG, "initFragment. mConversationFragment = "+ mConversationFragment);
        if (mConversationFragment == null) {
            /*

            String authCode = SampleAppStorage.getInstance(FragmentContainerActivity.this).getAuthCode();
            String publicKey = SampleAppStorage.getInstance(FragmentContainerActivity.this).getPublicKey();

            Log.d(TAG, "initFragment. authCode = "+ authCode);
            Log.d(TAG, "initFragment. publicKey = "+ publicKey);
            LPAuthenticationParams authParams = new LPAuthenticationParams();
            authParams.setAuthKey(authCode);
            authParams.addCertificatePinningKey(publicKey);
        */
            LPAuthenticationParams authParams =  new LPAuthenticationParams();
            CampaignInfo campaignInfo = null ;//SampleAppUtils.getCampaignInfo(this);
            ConversationViewParams params = new ConversationViewParams().setCampaignInfo(campaignInfo).setReadOnlyMode(isReadOnly());
            mConversationFragment = (ConversationFragment) LivePerson.getConversationFragment(authParams,params );

            if (isValidState()) {

                // Pending intent for image foreground service
                Intent notificationIntent = new Intent(this, ActivityCustom.class);
                notificationIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);
                LivePerson.setImageServicePendingIntent(pendingIntent);

                // Notification builder for image upload foreground service
                Notification.Builder uploadBuilder = 	new Notification.Builder(this.getApplicationContext());
                Notification.Builder downloadBuilder = 	new Notification.Builder(this.getApplicationContext());
                uploadBuilder.setContentTitle("Uploading image")
                        .setSmallIcon(android.R.drawable.arrow_up_float)
                        .setContentIntent(pendingIntent)
                        .setProgress(0, 0, true);

                downloadBuilder.setContentTitle("Downloading image")
                        .setSmallIcon(android.R.drawable.arrow_down_float)
                        .setContentIntent(pendingIntent)
                        .setProgress(0, 0, true);

                LivePerson.setImageServiceUploadNotificationBuilder(uploadBuilder);
                LivePerson.setImageServiceDownloadNotificationBuilder(downloadBuilder);

                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.add(R.id.custom_fragment_container, mConversationFragment, LIVEPERSON_FRAGMENT).commitAllowingStateLoss();
            }
        }else{
            attachFragment();
        }
    }

    private boolean isReadOnly() {
        return getIntent().getBooleanExtra(Infra.KEY_READ_ONLY, false);
    }

    private boolean isValidState() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            return !isFinishing() && !isDestroyed();
        }else{
            return !isFinishing();
        }
    }
    private void setCallBack() {
        //register via callback, also available to listen via BroadCastReceiver in Main Application
        MainActivity.getInstance().registerToLivePersonCallbacks();
    }

    private void attachFragment() {
        if (mConversationFragment.isDetached()) {
            Log.d(TAG, "initFragment. attaching fragment");
            if (isValidState()){
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.attach(mConversationFragment).commitAllowingStateLoss();
            }
        }
    }
}
