package com.bupa.mishk.mynewapplication.Utils;

public class AppStorage {

    public static final String brandID = "33136087";
    public static final String appID = "com.bupa.mishk.mynewapplication";
    public static final String SDK_SAMPLE_FCM_APP_ID = "com.bupa.mishk.mynewapplication";
   // public static final String SDK_SAMPLE_FCM_APP_ID = "1:510252700200:android:5ad4146296f11020";

    public static final String mAppinstallid = "63831102-5ed1-48ab-bd63-68e228f6abb4";

}
