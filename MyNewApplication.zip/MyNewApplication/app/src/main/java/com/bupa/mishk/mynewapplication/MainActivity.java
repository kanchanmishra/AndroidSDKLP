package com.bupa.mishk.mynewapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.liveperson.api.LivePersonCallback;
import com.liveperson.api.LivePersonCallbackImpl;
import com.liveperson.api.LivePersonIntents;
import com.liveperson.api.response.types.CloseReason;
import com.liveperson.api.sdk.LPConversationData;
import com.liveperson.api.sdk.PermissionType;
import com.liveperson.infra.InitLivePersonProperties;
import com.liveperson.infra.LPAuthenticationParams;
import com.liveperson.infra.MonitoringInitParams;
import com.liveperson.infra.callbacks.InitLivePersonCallBack;
import com.liveperson.infra.log.LPMobileLog;
import com.liveperson.messaging.TaskType;
import com.liveperson.messaging.model.AgentData;
import com.liveperson.messaging.sdk.api.LivePerson;
import com.liveperson.messaging.sdk.api.model.ConsumerProfile;
import com.bupa.mishk.mynewapplication.Utils.AppStorage;



public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    public static MainActivity Instance;
    private LivePersonCallbackImpl livePersonCallback;
    private BroadcastReceiver mLivePersonReceiver;
    private boolean showToastOnCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Instance = this;
        registerToLivePersonEvents();

        Button messagingButton = findViewById(R.id.messaging_button);
        Button monitoringButton = findViewById(R.id.monitoring_button);


        messagingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MonitoringInitParams monitoringInitParams = null;

                /*
                if (!isAccountIdValid()) {
                    Toast.makeText(IntroActivity.this, "Account ID not valid", Toast.LENGTH_SHORT).show();
                    return;
                }
                */
                // Initialize Monitoring only if AppInstallId was set
                //if(isAppInstallIdValid()) {
                    monitoringInitParams = new MonitoringInitParams(AppStorage.mAppinstallid);
                //}

                //storeParams();

                LivePerson.initialize(getApplicationContext(), new InitLivePersonProperties(AppStorage.brandID, AppStorage.SDK_SAMPLE_FCM_APP_ID, monitoringInitParams, new InitLivePersonCallBack() {

                    @Override
                    public void onInitSucceed() {
                        //enableLogoutButton(true);

                        Intent messagingIntent = new Intent(MainActivity.this, ActivityCustom.class);

                        startActivity(messagingIntent);
                    }

                    @Override
                    public void onInitFailed(Exception e) {
                        Toast.makeText(MainActivity.this, "Init failed", Toast.LENGTH_SHORT).show();
                    }
                }));

            }
        });

    }

    public void registerToLivePersonEvents(){
        createLivePersonReceiver();
        LocalBroadcastManager.getInstance(getApplicationContext())
                .registerReceiver(mLivePersonReceiver, LivePersonIntents.getIntentFilterForAllEvents());
    }

    private void createLivePersonReceiver() {
        if (mLivePersonReceiver != null){
            return;
        }
        mLivePersonReceiver = new BroadcastReceiver(){

            @Override
            public void onReceive(Context context, Intent intent) {

                Log.d(TAG, "Got LP intent event with action " + intent.getAction());
                switch (intent.getAction()){
                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_AGENT_AVATAR_TAPPED_INTENT_ACTION:
                        onAgentAvatarTapped(LivePersonIntents.getAgentData(intent));
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_AGENT_DETAILS_CHANGED_INTENT_ACTION:
                        AgentData agentData = LivePersonIntents.getAgentData(intent);
                        onAgentDetailsChanged(agentData);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_AGENT_TYPING_INTENT_ACTION:
                        boolean isTyping = LivePersonIntents.getAgentTypingValue(intent);
                        onAgentTyping(isTyping);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CONNECTION_CHANGED_INTENT_ACTION:
                        boolean isConnected = LivePersonIntents.getConnectedValue(intent);
                        onConnectionChanged(isConnected);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CONVERSATION_MARKED_AS_NORMAL_INTENT_ACTION:
                        onConversationMarkedAsNormal();
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CONVERSATION_MARKED_AS_URGENT_INTENT_ACTION:
                        onConversationMarkedAsUrgent();
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CONVERSATION_RESOLVED_INTENT_ACTION:
                        LPConversationData lpConversationData = LivePersonIntents.getLPConversationData(intent);
                        onConversationResolved(lpConversationData);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CONVERSATION_STARTED_INTENT_ACTION:
                        LPConversationData lpConversationData1 = LivePersonIntents.getLPConversationData(intent);
                        onConversationStarted(lpConversationData1);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CSAT_LAUNCHED_INTENT_ACTION:
                        onCsatLaunched();
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CSAT_DISMISSED_INTENT_ACTION:
                        onCsatDismissed();
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CSAT_SKIPPED_INTENT_ACTION:
                        onCsatSkipped();
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_CSAT_SUBMITTED_INTENT_ACTION:
                        String conversationId = LivePersonIntents.getConversationID(intent);
                        onCsatSubmitted(conversationId);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_ERROR_INTENT_ACTION:
                        TaskType type = LivePersonIntents.getOnErrorTaskType(intent);
                        String message = LivePersonIntents.getOnErrorMessage(intent);
                        onError(type, message);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_OFFLINE_HOURS_CHANGES_INTENT_ACTION:
                        onOfflineHoursChanges(LivePersonIntents.getOfflineHoursOn(intent));
                        break;

                    /*case LivePersonIntents.ILivePersonIntentAction.LP_ON_TOKEN_EXPIRED_INTENT_ACTION:
                        onTokenExpired();
                        break;
                    */
                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_USER_DENIED_PERMISSION:
                        PermissionType deniedPermissionType = LivePersonIntents.getPermissionType(intent);
                        boolean doNotShowAgainMarked = LivePersonIntents.getPermissionDoNotShowAgainMarked(intent);
                        onUserDeniedPermission(deniedPermissionType, doNotShowAgainMarked);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_USER_ACTION_ON_PREVENTED_PERMISSION:
                        PermissionType preventedPermissionType = LivePersonIntents.getPermissionType(intent);
                        onUserActionOnPreventedPermission(preventedPermissionType);
                        break;

                    case LivePersonIntents.ILivePersonIntentAction.LP_ON_STRUCTURED_CONTENT_LINK_CLICKED:
                        String uri = LivePersonIntents.getLinkUri(intent);
                        onStructuredContentLinkClicked(uri);
                        break;
                }

            }
        };
    }
    public void registerToLivePersonCallbacks(){
        createLivePersonCallback();
        LivePerson.setCallback(livePersonCallback);
    }


    private void createLivePersonCallback() {
        if (livePersonCallback != null){
            return;
        }
        livePersonCallback = new LivePersonCallbackImpl() {
            @Override
            public void onError(TaskType type, String message) {
                MainActivity.this.onError(type, message);
            }
/*
            @Override
            public void onTokenExpired() {
                MainActivity.this.onTokenExpired();
            }
*/
            @Override
            public void onConversationStarted(LPConversationData convData) {
                MainActivity.this.onConversationStarted(convData);
            }

            @Override
            public void onConversationResolved(LPConversationData convData) {
                MainActivity.this.onConversationResolved(convData);
            }

            @Override
            public void onConversationResolved(CloseReason reason) {
                /*Toast.makeText(getApplicationContext(), "onConversationResolved", Toast.LENGTH_LONG).show();*/
            }

            @Override
            public void onConnectionChanged(boolean isConnected) {
                MainActivity.this.onConnectionChanged(isConnected);
            }

            @Override
            public void onAgentTyping(boolean isTyping) {
                MainActivity.this.onAgentTyping(isTyping);
            }

            @Override
            public void onAgentDetailsChanged(AgentData agentData) {
                MainActivity.this.onAgentDetailsChanged(agentData);
            }

            @Override
            public void onCsatLaunched() {
                MainActivity.this.onCsatLaunched();
            }

            @Override
            public void onCsatDismissed() {
                MainActivity.this.onCsatDismissed();
            }

            @Override
            public void onCsatSubmitted(String conversationId) {
                MainActivity.this.onCsatSubmitted(conversationId);
            }

            @Override
            public void onCsatSkipped() {
                MainActivity.this.onCsatSkipped();
            }

            @Override
            public void onConversationMarkedAsUrgent() {
                MainActivity.this.onConversationMarkedAsUrgent();
            }

            @Override
            public void onConversationMarkedAsNormal() {
                MainActivity.this.onConversationMarkedAsNormal();
            }

            @Override
            public void onOfflineHoursChanges(boolean isOfflineHoursOn) {
                MainActivity.this.onOfflineHoursChanges(isOfflineHoursOn);
            }

            @Override
            public void onAgentAvatarTapped(AgentData agentData) {
                MainActivity.this.onAgentAvatarTapped(agentData);

            }

            @Override
            public void onUserDeniedPermission(PermissionType permissionType, boolean doNotShowAgainMarked) {
                MainActivity.this.onUserDeniedPermission(permissionType, doNotShowAgainMarked);
            }

            @Override
            public void onUserActionOnPreventedPermission(PermissionType permissionType) {
                MainActivity.this.onUserActionOnPreventedPermission(permissionType);
            }

            @Override
            public void onStructuredContentLinkClicked(String uri) {
                MainActivity.this.onStructuredContentLinkClicked(uri);
            }
        };
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public static MainActivity getInstance() {
        return Instance;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void setShowToastOnCallback(boolean showToastOnCallback) {
        this.showToastOnCallback = showToastOnCallback;
    }
    private void showToast(String message) {
        if (showToastOnCallback){
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
        }else{
            LPMobileLog.d(TAG + "_CALLBACK", message);
        }
    }

    private void onAgentAvatarTapped(AgentData agentData) {
        showToast("on Agent Avatar Tapped - " + agentData.mFirstName + " " + agentData.mLastName);
    }


    private void onOfflineHoursChanges(boolean isOfflineHoursOn) {
        showToast("on Offline Hours Changes - " + isOfflineHoursOn);
    }

    private void onConversationMarkedAsNormal() {
        showToast("Conversation Marked As Normal");
    }

    private void onConversationMarkedAsUrgent() {
        showToast("Conversation Marked As Urgent");
    }

    private void onCsatSubmitted(String conversationId) {
        showToast("on CSAT Submitted. ConversationID = " + conversationId);
    }

    private void onCsatLaunched() {
        showToast("on CSAT Launched");
    }

    private void onCsatDismissed() {
        showToast("on CSAT Dismissed");
    }

    private void onCsatSkipped() {
        showToast("on CSAT Skipped");
    }

    private void onAgentDetailsChanged(AgentData agentData) {
        showToast("Agent Details Changed " + agentData);
    }

    private void onAgentTyping(boolean isTyping) {
        showToast("isTyping " + isTyping);
    }

    private void onConnectionChanged(boolean isConnected) {
        showToast("onConnectionChanged " + isConnected);
    }

    private void onConversationResolved(LPConversationData convData) {
        showToast("Conversation resolved " + convData.getId()
                + " reason " + convData.getCloseReason());
    }

    private void onConversationStarted(LPConversationData convData) {
        showToast("Conversation started " + convData.getId()
                + " reason " + convData.getCloseReason());
    }
/*

    private void onTokenExpired() {
        showToast("onTokenExpired ");

        // Change authentication key here:
        LivePerson.reconnect(new LPAuthenticationParams().setAuthKey(SampleAppStorage.getInstance(getApplicationContext()).getAuthCode()));
    }
  */

    private void onError(TaskType type, String message) {
        showToast(" problem " + type.name());
    }

    private void onUserDeniedPermission(PermissionType permissionType, boolean doNotShowAgainMarked) {
        showToast("onUserDeniedPermission " + permissionType.name() + " doNotShowAgainMarked = " + doNotShowAgainMarked);
    }

    private void onUserActionOnPreventedPermission(PermissionType permissionType) {
        showToast("onUserActionOnPreventedPermission " + permissionType.name());
    }

    private void onStructuredContentLinkClicked(String uri) {
        showToast("onStructuredContentLinkClicked. Uri: " + uri);
    }
}
